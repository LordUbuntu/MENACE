# MENACE
A reproduction of M.E.N.A.C.E. in Python
